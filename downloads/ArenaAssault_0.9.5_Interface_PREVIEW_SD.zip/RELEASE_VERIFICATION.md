# Arena Assault 0.9.5 Interface Preview — verification

2026-10-12. Wii U / Aroma. Independent ArenaAssaultInterfacePreview app/save path.
The user reports that an earlier 0.9 build runs on Wii U. This environment has
no console or emulator: rendering, AX sound, SD persistence and FPS need hardware validation.

## Changes and source adaptations

Accepted hostile damage starts a 0.10 s material flash across all visible
soldier parts, without new geometry or shaders. Friendlies, walls and spawn
protection do not produce confirmation. Hit/Headshot/Kill markers are distinct;
kill priority survives multiple pellets. Spawn and restart clear transient state.

Camera recoil impulse and weapon kick adapt Kenney Starter-Kit-FPS (MIT).
Squared trauma/decay adapts Godot TPS Demo code (MIT). A lightweight sine
oscillator replaces FastNoiseLite; no Godot runtime, heavy physics engine or
upstream art is copied. Original files, licenses, URLs and hashes are in
third_party/CombatSources. Aiming reduces kick; camera picking sees recoil so
crosshair and muzzle targeting use the displayed direction. Class weapon damage,
magazines, fire rates, spread and HP remain unchanged; no falloff/armor rebalance.

Native GX2 HUD has larger magazine count, reserve, timed reload progress,
low-HP/ammo colors and attack direction from accepted damage source. ImGui
extends Settings (tabs/sliders), Pause, Controls and Results. Menu transitions
have one owner; the pause edge cannot immediately resume the same frame.
Settings from pause return to pause. Edits persist on Back/shutdown rather than
on every drag frame. Independent TV/DRC contexts remain; GamePad displays the
original tactical map outside the main menu. Original UI remains an init fallback.

## Verification

29 C++ tests and four Python checks pass, also under ASan/UBSan (leak detection
disabled in this environment). Tests cover accepted/protected/friendly flashes,
expiry, marker classes, camera decay/reset/invalid delta, actual Game model
materials, reload bar/damage direction/low HP, real ImGui actions/navigation,
Game transitions and inherited gameplay/save/assets. Host graphics/audio
facades do not emulate GX2 or AX. Independent code review accompanies release.

Native devkitPPC GCC 16.1.0/WUT creates RPX/WUHB using bundled GSH shaders.
ZIP checks verify CRC, payload SHA256, install path, metadata and source/license
completeness. Exact payload evidence: docs/BUILD_PROOF.json.

CPU previews capture real ImGui geometry, Game soldier transforms and native
HUD rectangle submissions; simplified CPU lighting/background do not emulate
GX2. They are not Wii U screenshots. 60 FPS is a target, not a measurement.

## 0.9.5 UI change

Polish labels are consistent across native HUD, map, fallback screens, ImGui and startup assets. DejaVu Sans font and license are embedded; Latin Extended range supports Polish letters. Native text counts UTF-8 codepoints and supplies Polish bitmap glyphs, without a new shader. Three objective cards have owner/contested captions, actual progress and separated percentage/bar rows. A nearby-objective panel uses the simulation capture radius (3.8 m). Native progress rendering adapts the clamp/frame/linear-fill part of pinned ImGui::ProgressBar; upstream reference and provenance are in third_party/HudSources.

Added tests verify Polish class display, HUD bounds and caption spacing, capture state/percent, safe progress clamping and malformed UTF-8. Font glyph checks and existing gamepad actions remain covered. Independent review identified status/percentage collision and English startup captions; both corrected, with a focused ASan/UBSan layout recheck. Gameplay balance is unchanged.
